
#------------------------------------------------------------------------------
# Project 'IEEE30_60HZ' make using the 'GFortran 4.2.1' compiler.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# All project
#------------------------------------------------------------------------------

all: targets
	@echo !--Make: succeeded.



#------------------------------------------------------------------------------
# Directories, Platform, and Version
#------------------------------------------------------------------------------

Arch        = windows
EmtdcDir    = C:\PROGAR~1\PSCAD46\emtdc\gf42
EmtdcInc    = $(EmtdcDir)\inc
EmtdcBin    = $(EmtdcDir)\$(Arch)
EmtdcMain   = $(EmtdcBin)\main.obj
EmtdcLib    = $(EmtdcBin)\emtdc.lib


#------------------------------------------------------------------------------
# Fortran Compiler
#------------------------------------------------------------------------------

FC_Name         = gfortran.exe
FC_Suffix       = o
FC_Args         = -c -ffree-form -fdefault-real-8
FC_Debug        = 
FC_Preprocess   = 
FC_Preproswitch = 
FC_Warn         = -Wconversion
FC_Checks       = 
FC_Includes     = -I"$(EmtdcInc)" -I"$(EmtdcBin)"
FC_Compile      = $(FC_Name) $(FC_Args) $(FC_Includes) $(FC_Debug) $(FC_Warn) $(FC_Checks)

#------------------------------------------------------------------------------
# C Compiler
#------------------------------------------------------------------------------

CC_Name     = gcc.exe
CC_Suffix   = o
CC_Args     = -c
CC_Debug    = 
CC_Includes = -I"$(EmtdcInc)" -I"$(EmtdcBin)"
CC_Compile  = $(CC_Name) $(CC_Args) $(CC_Includes) $(CC_Debug)

#------------------------------------------------------------------------------
# Linker
#------------------------------------------------------------------------------

Link_Name   = gcc.exe
Link_Debug  = 
Link_Args   = -o $@
Link        = $(Link_Name) $(Link_Args) $(Link_Debug)

#------------------------------------------------------------------------------
# Build rules for generated files
#------------------------------------------------------------------------------


%.$(FC_Suffix): %.f
	@echo !--Compile: $<
	$(FC_Compile) $<


%.$(CC_Suffix): %.c
	@echo !--Compile: $<
	$(CC_Compile) $<



#------------------------------------------------------------------------------
# Build rules for file references
#------------------------------------------------------------------------------


#------------------------------------------------------------------------------
# Dependencies
#------------------------------------------------------------------------------


FC_Objects = \
 Station.$(FC_Suffix) \
 Main.$(FC_Suffix) \
 psse.$(FC_Suffix) \
 Inverter2.$(FC_Suffix) \
 InvCtl2.$(FC_Suffix) \
 T26_29.$(FC_Suffix) \
 T26_28.$(FC_Suffix) \
 Rectifier2.$(FC_Suffix) \
 T25_26.$(FC_Suffix) \
 Rectifier_AC2.$(FC_Suffix) \
 T28_29.$(FC_Suffix) \
 T2_25.$(FC_Suffix) \
 T26_27.$(FC_Suffix) \
 T17_27.$(FC_Suffix) \
 T1_2.$(FC_Suffix) \
 T17_18.$(FC_Suffix) \
 T2_3.$(FC_Suffix) \
 T3_18.$(FC_Suffix) \
 T16_17.$(FC_Suffix) \
 T16_24.$(FC_Suffix) \
 T1_39.$(FC_Suffix) \
 T15_16.$(FC_Suffix) \
 T3_4.$(FC_Suffix) \
 T16_21.$(FC_Suffix) \
 T23_24.$(FC_Suffix) \
 Inverter3.$(FC_Suffix) \
 InvCtl3.$(FC_Suffix) \
 Rectifier_AC.$(FC_Suffix) \
 T21_22.$(FC_Suffix) \
 Rectifier.$(FC_Suffix) \
 Rectifier3.$(FC_Suffix) \
 T14_15.$(FC_Suffix) \
 T4_14.$(FC_Suffix) \
 Rectifier_AC3.$(FC_Suffix) \
 Inverter.$(FC_Suffix) \
 InvCtl.$(FC_Suffix) \
 T4_5.$(FC_Suffix) \
 T16_19.$(FC_Suffix) \
 T22_23.$(FC_Suffix) \
 T5_6.$(FC_Suffix) \
 T13_14.$(FC_Suffix) \
 T5_8.$(FC_Suffix) \
 T9_39.$(FC_Suffix) \
 T6_7.$(FC_Suffix) \
 T6_11.$(FC_Suffix) \
 T7_8.$(FC_Suffix) \
 T10_11.$(FC_Suffix) \
 T10_13.$(FC_Suffix) \
 T8_9.$(FC_Suffix)

FC_ObjectsLong = \
 "Station.$(FC_Suffix)" \
 "Main.$(FC_Suffix)" \
 "psse.$(FC_Suffix)" \
 "Inverter2.$(FC_Suffix)" \
 "InvCtl2.$(FC_Suffix)" \
 "T26_29.$(FC_Suffix)" \
 "T26_28.$(FC_Suffix)" \
 "Rectifier2.$(FC_Suffix)" \
 "T25_26.$(FC_Suffix)" \
 "Rectifier_AC2.$(FC_Suffix)" \
 "T28_29.$(FC_Suffix)" \
 "T2_25.$(FC_Suffix)" \
 "T26_27.$(FC_Suffix)" \
 "T17_27.$(FC_Suffix)" \
 "T1_2.$(FC_Suffix)" \
 "T17_18.$(FC_Suffix)" \
 "T2_3.$(FC_Suffix)" \
 "T3_18.$(FC_Suffix)" \
 "T16_17.$(FC_Suffix)" \
 "T16_24.$(FC_Suffix)" \
 "T1_39.$(FC_Suffix)" \
 "T15_16.$(FC_Suffix)" \
 "T3_4.$(FC_Suffix)" \
 "T16_21.$(FC_Suffix)" \
 "T23_24.$(FC_Suffix)" \
 "Inverter3.$(FC_Suffix)" \
 "InvCtl3.$(FC_Suffix)" \
 "Rectifier_AC.$(FC_Suffix)" \
 "T21_22.$(FC_Suffix)" \
 "Rectifier.$(FC_Suffix)" \
 "Rectifier3.$(FC_Suffix)" \
 "T14_15.$(FC_Suffix)" \
 "T4_14.$(FC_Suffix)" \
 "Rectifier_AC3.$(FC_Suffix)" \
 "Inverter.$(FC_Suffix)" \
 "InvCtl.$(FC_Suffix)" \
 "T4_5.$(FC_Suffix)" \
 "T16_19.$(FC_Suffix)" \
 "T22_23.$(FC_Suffix)" \
 "T5_6.$(FC_Suffix)" \
 "T13_14.$(FC_Suffix)" \
 "T5_8.$(FC_Suffix)" \
 "T9_39.$(FC_Suffix)" \
 "T6_7.$(FC_Suffix)" \
 "T6_11.$(FC_Suffix)" \
 "T7_8.$(FC_Suffix)" \
 "T10_11.$(FC_Suffix)" \
 "T10_13.$(FC_Suffix)" \
 "T8_9.$(FC_Suffix)"

CC_Objects =

CC_ObjectsLong =

UserLibs =

SysLibs  = -lgfortran -lstdc++ -lwsock32

Binary   = IEEE30_60HZ.exe

$(Binary): $(FC_Objects) $(CC_Objects) $(UserLibs)
	@echo !--Link: $@
	$(Link) "$(EmtdcMain)" *.$(CC_Suffix) $(UserLibs) "$(EmtdcLib)" $(SysLibs)

targets: $(Binary)


clean:
	-del EMTDC_V*
	-del *.obj
	-del *.o
	-del *.exe
	@echo !--Make clean: succeeded.



