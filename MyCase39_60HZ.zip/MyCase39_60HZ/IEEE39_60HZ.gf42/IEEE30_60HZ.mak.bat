call "C:\Progarm Files_Shao\GFortran421\bin\gf42vars.bat"
pushd "D:\SynologyDrive\Code_PSCAD\MyCase39_4_60HZͬ����ԭʼ�汾\IEEE30_60HZ.gf42\"
make -f IEEE30_60HZ.mak
popd
