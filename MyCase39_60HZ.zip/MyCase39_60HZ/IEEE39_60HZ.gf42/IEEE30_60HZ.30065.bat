call "D:\Program Files_Shao\GFortran\bin\gf42vars.bat"
pushd "D:\SynologyDrive\Code_PSCAD\MyCase39_4_60HZͬ����ԭʼ�汾\IEEE30_60HZ.gf42\"
IEEE30_60HZ.exe -v4 169.254.83.107 30065 locale=english-us
popd
